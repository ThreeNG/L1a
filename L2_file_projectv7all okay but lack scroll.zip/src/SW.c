#include "SW.h"

char ch;
int matchtime;

boolean pollingSW1(void);
boolean pollingSW1(void);

/******************************************************************************
* Function Name: pollingSW1SW2
* Description  : check SW1 and SW2 are pressed at the same time
* Arguments    : none
* Return Value : ON/OFF
******************************************************************************/
boolean pollingSW1SW2(void)
{	
		int match;
		*PORTPM7 = (*PORTPM7 | SW1_MASK|SW2_MASK);
		ch = *PORT7; // Read P7
		return OFF;
		
		
		
		
}

/******************************************************************************
* Function Name: pollingSW1
* Description  : check SW1 is pressed return value only when release button
* Arguments    : none
* Return Value : ON/OFF
******************************************************************************/
boolean pollingSW1(void)
	{	
		*PORTPM7 = (*PORTPM7 | SW1_MASK);
		ch = *PORT7; // Read P7
		if (ch & SW1_MASK){
			matchtime = 0;
			return OFF;
		}else {
			matchtime++;
			if (matchtime >=3) {
				matchtime = 0;
				return ON;
			}
		}
	}

/******************************************************************************
* Function Name: pollingSW2
* Description  : check SW2 is pressed return value only when release button
* Arguments    : none
* Return Value : ON/OFF
******************************************************************************/
boolean pollingSW2(void)
	{	
		*PORTPM7 = (*PORTPM7 | SW2_MASK);
		ch = *PORT7; // Read P7
		if(ch & SW2_MASK){
			matchtime = 0;
			return OFF;
		}else {
			matchtime++;
			if (matchtime >=3) {
				matchtime = 0;
				return ON;
			}
		}
	}
/******************************************************************************
* Function Name: pollingSW3
* Description  : check SW3 is pressed return value only when release button
* Arguments    : none
* Return Value : ON/OFF
******************************************************************************/
boolean pollingSW3()
	{	
		*PORTPM7 = (*PORTPM7 | SW3_MASK);
		ch = *PORT7; // Read P7
		if (ch & SW3_MASK){
			matchtime = 0;
			return OFF;
		}else {
			matchtime++;
			if (matchtime >=3) {
				matchtime = 0;
				return ON;
			}
		}
	}
