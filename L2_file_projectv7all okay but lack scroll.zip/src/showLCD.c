#include "showLCD.h"

char status;
int time_change_stt;
char* stringtime[10];
/******************************************************************************
* Function Name: Display_LCD
* Description  : caculate time and display LCD in case of variable status 0: SETTING, 1: Paused, 2: Counting
* Arguments    : none
* Return Value : none
******************************************************************************/
void show_LCD(int row, char* string_shown_on_lcd )
{	/*if (status == 'r')
		DisplayLCD(LCD_LINE1,(unsigned char *)"Running..."); 
	if (status == 'p')
		DisplayLCD(LCD_LINE1,(unsigned char *)"Pausing..."); 
	if (status == 'n')
		DisplayLCD(LCD_LINE1,(unsigned char *)"No record");
	if (status == 'f')
		DisplayLCD(LCD_LINE1,(unsigned char *)"First record");
	if (status == 'l')
		DisplayLCD(LCD_LINE1,(unsigned char *)"Last record");
	*/
	DisplayLCD(row, string_shown_on_lcd);
}
/******************************************************************************
* Function Name: LCD_reset
* Description  : reset LCD to setting with time = 0
* Arguments    : none
* Return Value : none
******************************************************************************/
void LCD_reset()
{	/* Clear LCD display */
	ClearLCD();	
	status = 'p';
	DisplayLCD(LCD_LINE1,(unsigned char *)"Pausing...");
	sprintf(stringtime, "%d:%d:%d  ",0, 0, 0);
	show_LCD(LCD_LINE2, stringtime);
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit()
{	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();	
}
