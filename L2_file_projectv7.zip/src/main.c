#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "showLCD.h"
#include "SW.h"
#include "api.h"
	
/******************************************************************************
Macro definitions
******************************************************************************/
/******************************************************************************
Typedef definitions
******************************************************************************/
typedef struct
	{
	int minute;
	int second;
	int centi;
	} time_t;

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern char status;
extern int time_change_stt;  // flag for paused and counting no record
volatile int G_elapsedTime;   // Timer Counter
time_t curr, prev[19];
extern char* stringtime[10];
char* stringrecord[12];
extern int matchtime;
int lineNo;
int recordNo;
int recordIndex;
int recordflag;
int recordcount;
int show2scount;
int timesave;
int up;
int down;
int upcount;
int downcount;
int recordshowcount;


/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/


/******************************************************************************
Private global variables and functions
******************************************************************************/

void delay_10CentiS()
{
	timesave = G_elapsedTime;
	while (timesave >= G_elapsedTime - 10 );
}

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main()
{	R_IT_Create();
	R_IT_Start();
	/* Initialize user system */
	r_main_userinit();
	LCD_reset();
	//recordNo = 1;
	//lineNo = LCD_LINE3;
	recordflag = 0;
	status = 'p';
	//rollupcount = 0;
	//rolldowncount = 0;
	
	/* Infinit loop */
	while (1U)
		{
		delay_10CentiS();
		if (pollingSW1()) 
			{
			/*print record from [2] to [2+6 
				upcount++;	
					for (up = 1; up <= 6; up++)
						{
						recordIndex = up - 1;
						lineNo = recordNo*8+ LCD_LINE2;
						sprintf(stringtime, "#%d: %d:%d:%d  ",recordNo, prev[recordIndex].minute, prev[recordIndex].second, prev[recordIndex].centi);
						show_LCD(lineNo, stringtime);
						} */

				
			if (!recordflag)
				{
				G_elapsedTime = 0;
				DisplayLCD(LCD_LINE1,(unsigned char *)"No record");					
				}
			else
				{
				show2scount = 0;
				DisplayLCD(LCD_LINE1,(unsigned char *)"First record");	
				}
			}			
		if (pollingSW2())  //scroll down is writing
			{
			
			
			
			if (!recordflag)
				{
				G_elapsedTime = 0;
				DisplayLCD(LCD_LINE1,(unsigned char *)"No record");					
				}
			else
				{
				show2scount = 0;
				DisplayLCD(LCD_LINE1,(unsigned char *)"Last record");
				
				}
			}
		switch (status)
			{
			case 'p' :
				if (G_elapsedTime >= 200)	// show No record in 2s
					DisplayLCD(LCD_LINE1,(unsigned char *)"Pausing...");
					
				if (pollingSW1SW2())
					{					
					LCD_reset();
					recordflag = 0;
					recordshowcount = 0;
					recordcount = 0;
					}				
				if (pollingSW3())
					{
					status = 'r';
					DisplayLCD(LCD_LINE1,(unsigned char *)"Running...");
					}					
				break;
			case 'r' :
				
					/* show last or first record in 2s */
				if (show2scount >= 2)
					DisplayLCD(LCD_LINE1,(unsigned char *)"Running...");
					
				if (pollingSW1SW2())
					{
					status = 'p';
					DisplayLCD(LCD_LINE1,(unsigned char *)"Pausing...");
					}			
				if (G_elapsedTime >= (curr.centi + 1))
					{
					curr.centi = G_elapsedTime;
					if (G_elapsedTime >= 99)
						{
						curr.second ++;							
						show2scount++;
						G_elapsedTime = 0;
						curr.centi = 0;
						}
					if (curr.second >= 59)
						{
						curr.minute++;
						curr.second = 0;
						}
					if (curr.minute >= 99)
						{
						curr.minute = 0;
						}	
					sprintf(stringtime, "%d:%d:%d      ",curr.minute, curr.second, curr.centi);
					show_LCD(LCD_LINE2, stringtime);
					}				
				if (pollingSW3())
					{
					if (recordcount <= 20)
						recordcount++;
					/*set record from No20 to No2  */
					for (recordNo = recordcount; recordNo >= 1; recordNo--)
						{
						recordIndex = recordNo - 1;
						prev[recordNo].centi = prev[recordIndex].centi;
						prev[recordNo].second = prev[recordIndex].second;
						prev[recordNo].minute = prev[recordIndex].minute;
						}
					/* set record No1 */
					prev[0].centi = curr.centi;
					prev[0].second = curr.second;
					prev[0].minute = curr.minute;
					/*print record from No1 to recordcount */
					if (recordshowcount < 6)
						recordshowcount++;
					for (recordNo = 1; recordNo <= recordshowcount; recordNo++)
						{
						recordIndex = recordNo - 1;
						lineNo = recordNo*8+ LCD_LINE2;
						sprintf(stringtime, "#%d: %d:%d:%d  ",recordNo, prev[recordIndex].minute, prev[recordIndex].second, prev[recordIndex].centi);
						show_LCD(lineNo, stringtime);
						}
					//show_LCD(lineNo, stringtime);// record elapsed timeprint record if 3< lineNo <= 8, print line - 2  or lineNo = lineNo - 1 while lineNo<=20 only when availabe line, recordfla
					//record flag = 0;
					recordflag = 1;
					}
				break;
			default :
				break;
			}
		}
}

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}
/******************************************************************************
End of file
******************************************************************************/
