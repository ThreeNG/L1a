#include "api.h"

void R_IT_Create(void)
{
    RTCEN   = 1U;       /* supply timer clock      */
    ITMC    = 0x00U;       /* disable timer operation */
    ITMK    = 1U;       /* disable timer interrupt */
    ITIF    = 0U;       /* clear timer interrupt flag */

    OSMC    = 0x10U;    /* Select clock source: Low-speed on-chip oscillator clock */

    ITMC    = 0x0095U; /* Configure timer data register */
}

void R_IT_Start(void)
{
    ITMC    = ITMC |0x8000U;  /* enable timer operation     */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMK    = 0U;       /* enable timer interrupt     */
}

void R_IT_Stop(void)
{
    ITMK    = 1U;       /* disable timer interrupt    */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMC    = ITMC & 0x7fffU;  /* disable timer operation    */
}
