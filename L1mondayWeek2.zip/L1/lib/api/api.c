#include "api.h"
#include "api.h"
//Define the functions in api.h




//Wait for M mili-second:
//Refer to the description of the exercise
//to see how to write this function
void wait(int M)
{
	unsigned long i=1778;
	i= i*M ;
	while (i!=0)
	{	
	i--;
	}	
}
