#ifndef API_H
#define API_H

#include "r_macro.h"  /* System macro and standard type definition */
//Off all the LEDs
void off();

//On all the LEDs
void on();

//Wait for M mili-second
void wait(int M);

#endif